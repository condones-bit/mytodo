import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../context/ThemeContext';
import SpatialCard from './SpatialCard';
import PriorityBadge from './PriorityBadge';

export default function TaskCard({ task, onPress, onToggle, onDelete }) {
  const { theme } = useTheme();
  const c = theme.colors;

  return (
    <TouchableOpacity activeOpacity={0.85} onPress={onPress}>
      <SpatialCard style={styles.card}>
        <TouchableOpacity onPress={onToggle} hitSlop={8} style={styles.checkWrap}>
          <View
            style={[
              styles.check,
              { borderColor: c.accent },
              task.completed && { backgroundColor: c.accent },
            ]}
          >
            {task.completed && <Ionicons name="checkmark" size={16} color={c.white} />}
          </View>
        </TouchableOpacity>

        <View style={styles.body}>
          <Text
            style={[
              styles.title,
              { color: c.textPrimary },
              task.completed && { color: c.textMuted, textDecorationLine: 'line-through' },
            ]}
            numberOfLines={1}
          >
            {task.title}
          </Text>

          {!!task.description && (
            <Text style={[styles.desc, { color: c.textSecondary }]} numberOfLines={1}>
              {task.description}
            </Text>
          )}

          <View style={styles.metaRow}>
            <PriorityBadge priority={task.priority} />
            {!!task.category && (
              <View style={[styles.categoryPill, { backgroundColor: c.primarySoft }]}>
                <Text style={[styles.categoryText, { color: c.primary }]}>{task.category}</Text>
              </View>
            )}
            {!!task.dueDate && (
              <Text style={[styles.dueDate, { color: c.textMuted }]}>{task.dueDate}</Text>
            )}
          </View>
        </View>

        <TouchableOpacity onPress={onDelete} hitSlop={8} style={styles.deleteWrap}>
          <Ionicons name="trash-outline" size={18} color={c.danger} />
        </TouchableOpacity>
      </SpatialCard>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12, padding: 14 },
  checkWrap: { marginRight: 12, marginTop: 2 },
  check: {
    width: 24,
    height: 24,
    borderRadius: 8,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { flex: 1 },
  title: { fontSize: 15, fontWeight: '700', marginBottom: 2 },
  desc: { fontSize: 13, marginBottom: 8 },
  metaRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
  categoryPill: { borderRadius: 999, paddingVertical: 3, paddingHorizontal: 9 },
  categoryText: { fontSize: 11, fontWeight: '700' },
  dueDate: { fontSize: 11, fontWeight: '600' },
  deleteWrap: { marginLeft: 8, marginTop: 4 },
});