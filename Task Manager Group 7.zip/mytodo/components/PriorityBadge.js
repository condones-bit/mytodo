import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../context/ThemeContext';

const TONE_BY_PRIORITY = {
  High: 'danger',
  Medium: 'warning',
  Low: 'success',
};

export default function PriorityBadge({ priority = 'Medium' }) {
  const { theme } = useTheme();
  const tone = TONE_BY_PRIORITY[priority] || 'warning';
  const bg = theme.colors[`${tone}Soft`];
  const fg = theme.colors[tone];

  return (
    <View style={[styles.badge, { backgroundColor: bg, borderRadius: theme.radius.pill }]}>
      <View style={[styles.dot, { backgroundColor: fg }]} />
      <Text style={[styles.text, { color: fg }]}>{priority}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 10,
    alignSelf: 'flex-start',
  },
  dot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  text: { fontSize: 11, fontWeight: '700' },
});