import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTheme } from '../context/ThemeContext';

// A floating, rounded surface. Pass `glass` for a translucent variant (use over
// a colored/gradient background), or `elevated={false}` to drop the shadow for
// a flatter nested card.
export default function SpatialCard({ children, style, glass = false, elevated = true }) {
  const { theme } = useTheme();

  return (
    <View
      style={[
        styles.card,
        { borderRadius: theme.radius.lg },
        {
          backgroundColor: glass ? theme.colors.glass : theme.colors.surfaceElevated,
          borderColor: theme.colors.border,
        },
        elevated && theme.shadow.card,
        style,
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: StyleSheet.hairlineWidth,
    padding: 16,
  },
});