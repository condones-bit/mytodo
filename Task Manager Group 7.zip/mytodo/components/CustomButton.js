import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useTheme } from '../context/ThemeContext';

// variant: 'primary' (accent fill) | 'secondary' (navy fill) | 'outline' | 'danger'
export default function CustomButton({
  title,
  onPress,
  variant = 'primary',
  loading = false,
  disabled = false,
  style,
}) {
  const { theme } = useTheme();
  const c = theme.colors;

  const variants = {
    primary: { backgroundColor: c.accent, textColor: c.white, borderColor: 'transparent' },
    secondary: { backgroundColor: c.primary, textColor: c.textInverse, borderColor: 'transparent' },
    outline: { backgroundColor: 'transparent', textColor: c.textPrimary, borderColor: c.border },
    danger: { backgroundColor: 'transparent', textColor: c.danger, borderColor: c.danger },
  };
  const v = variants[variant] || variants.primary;

  return (
    <TouchableOpacity
      style={[
        styles.button,
        { borderRadius: theme.radius.md },
        {
          backgroundColor: v.backgroundColor,
          borderColor: v.borderColor,
          borderWidth: v.borderColor === 'transparent' ? 0 : 1.5,
          opacity: disabled ? 0.5 : 1,
        },
        variant === 'primary' && theme.shadow.card,
        style,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.85}
    >
      {loading ? (
        <ActivityIndicator color={v.textColor} />
      ) : (
        <Text style={[styles.text, { color: v.textColor }]}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { fontSize: 15, fontWeight: '700' },
});