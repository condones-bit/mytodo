import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../context/ThemeContext';
import SpatialCard from './SpatialCard';

// tone: any key on theme.colors that resolves to a color (e.g. 'accent', 'success', 'danger', 'primary')
export default function StatCard({ label, value, tone = 'primary' }) {
  const { theme } = useTheme();
  const accentColor = theme.colors[tone] || theme.colors.primary;

  return (
    <SpatialCard style={styles.card}>
      <View style={[styles.accentBar, { backgroundColor: accentColor }]} />
      <Text style={[styles.value, { color: theme.colors.textPrimary }]}>{value}</Text>
      <Text style={[styles.label, { color: theme.colors.textSecondary }]}>{label}</Text>
    </SpatialCard>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, paddingTop: 14, paddingBottom: 14 },
  accentBar: { width: 28, height: 4, borderRadius: 2, marginBottom: 10 },
  value: { fontSize: 22, fontWeight: '800' },
  label: { fontSize: 12, fontWeight: '600', marginTop: 2 },
});