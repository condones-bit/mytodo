import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS, createTask } from '../constants/storage';
import { useAuth } from './AuthContext';

const TaskContext = createContext(null);

function tasksKeyFor(username) {
  // Each user gets their own list of tasks, stored under their own key.
  return `${STORAGE_KEYS.TASKS}:${username}`;
}

function normalizeTask(t) {
  // Fills in dueDate/priority/category for tasks saved before those fields existed,
  // so older stored data never causes undefined values in the UI.
  return {
    dueDate: '',
    priority: 'Medium',
    category: 'Other',
    ...t,
  };
}

export function TaskProvider({ children }) {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [tasksReady, setTasksReady] = useState(false);

  // Load this user's tasks whenever they log in (or clear them on logout).
  useEffect(() => {
    async function loadTasks() {
      if (!user) {
        setTasks([]);
        setTasksReady(true);
        return;
      }
      setTasksReady(false);
      try {
        const raw = await AsyncStorage.getItem(tasksKeyFor(user.username));
        const parsed = raw ? JSON.parse(raw) : [];
        setTasks(parsed.map(normalizeTask));
      } catch (e) {
        setTasks([]);
      } finally {
        setTasksReady(true);
      }
    }
    loadTasks();
  }, [user]);

  const persist = async (nextTasks) => {
    setTasks(nextTasks);
    if (user) {
      await AsyncStorage.setItem(tasksKeyFor(user.username), JSON.stringify(nextTasks));
    }
  };

  // fields: { title, description, dueDate, priority, category }
  const addTask = async (fields) => {
    const title = (fields?.title || '').trim();
    if (!title) return;
    const newTask = createTask({ ...fields, title });
    await persist([newTask, ...tasks]);
  };

  const toggleTask = async (id) => {
    const next = tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t));
    await persist(next);
  };

  // fields: { title, description, dueDate, priority, category }
  const editTask = async (id, fields) => {
    const title = (fields?.title || '').trim();
    if (!title) return;
    const next = tasks.map((t) =>
      t.id === id
        ? {
            ...t,
            ...fields,
            title,
          }
        : t
    );
    await persist(next);
  };

  const deleteTask = async (id) => {
    const next = tasks.filter((t) => t.id !== id);
    await persist(next);
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        tasksReady,
        addTask,
        toggleTask,
        editTask,
        deleteTask,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
}

export function useTasks() {
  const ctx = useContext(TaskContext);
  if (!ctx) {
    throw new Error('useTasks must be used inside TaskProvider');
  }
  return ctx;
}