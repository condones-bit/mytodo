import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '../constants/storage';
import { lightTheme, darkTheme } from '../constants/theme';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [mode, setMode] = useState('light');
  const [themeReady, setThemeReady] = useState(false);

  useEffect(() => {
    async function loadTheme() {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEYS.THEME);
        if (saved === 'dark' || saved === 'light') {
          setMode(saved);
        }
      } catch (e) {
        // Fall back to light mode if storage read fails.
      } finally {
        setThemeReady(true);
      }
    }
    loadTheme();
  }, []);

  const toggleTheme = async () => {
    const next = mode === 'light' ? 'dark' : 'light';
    setMode(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.THEME, next);
    } catch (e) {
      // UI already switched; persistence failing isn't fatal.
    }
  };

  const setThemeMode = async (nextMode) => {
    if (nextMode !== 'light' && nextMode !== 'dark') return;
    setMode(nextMode);
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.THEME, nextMode);
    } catch (e) {
      // ignore
    }
  };

  const theme = mode === 'dark' ? darkTheme : lightTheme;

  return (
    <ThemeContext.Provider value={{ theme, mode, themeReady, toggleTheme, setThemeMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme must be used inside ThemeProvider');
  }
  return ctx;
}