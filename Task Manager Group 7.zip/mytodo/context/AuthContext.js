import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '../constants/storage';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [user, setUser] = useState(null);
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    async function loadAuth() {
      try {
        const [onboardedValue, sessionValue] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.ONBOARDED),
          AsyncStorage.getItem(STORAGE_KEYS.SESSION),
        ]);
        setHasOnboarded(onboardedValue === 'true');
        setUser(sessionValue ? JSON.parse(sessionValue) : null);
      } catch (e) {
        setHasOnboarded(false);
        setUser(null);
      } finally {
        setReady(true);
      }
    }
    loadAuth();
  }, []);

  const completeOnboarding = async () => {
    await AsyncStorage.setItem(STORAGE_KEYS.ONBOARDED, 'true');
    setHasOnboarded(true);
  };

  const register = async (fullName, username, password) => {
    setAuthError('');
    const name = fullName.trim();
    const userName = username.trim();
    if (!name || !userName || !password) {
      setAuthError('All fields are required.');
      return false;
    }
    if (password.length < 4) {
      setAuthError('Password must be at least 4 characters.');
      return false;
    }

    const raw = await AsyncStorage.getItem(STORAGE_KEYS.USERS);
    const users = raw ? JSON.parse(raw) : [];
    if (users.some((u) => u.username.toLowerCase() === userName.toLowerCase())) {
      setAuthError('Username already exists.');
      return false;
    }

    const newUser = { fullName: name, username: userName, password };
    users.push(newUser);
    const session = { fullName: name, username: userName };
    await AsyncStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    await AsyncStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
    setUser(session);
    return true;
  };

  const login = async (username, password) => {
    setAuthError('');
    const raw = await AsyncStorage.getItem(STORAGE_KEYS.USERS);
    const users = raw ? JSON.parse(raw) : [];
    const found = users.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password
    );
    if (!found) {
      setAuthError('Invalid username or password.');
      return false;
    }
    const session = { fullName: found.fullName, username: found.username };
    await AsyncStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
    setUser(session);
    return true;
  };

  const logout = async () => {
    await AsyncStorage.removeItem(STORAGE_KEYS.SESSION);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        ready,
        hasOnboarded,
        user,
        authError,
        setAuthError,
        completeOnboarding,
        register,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}