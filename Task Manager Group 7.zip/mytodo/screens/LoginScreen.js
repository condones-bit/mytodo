import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import SpatialCard from '../components/SpatialCard';

export default function LoginScreen() {
  const { login, register, authError, setAuthError } = useAuth();
  const { theme } = useTheme();
  const c = theme.colors;

  const [isRegister, setIsRegister] = useState(false);
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async () => {
    setSubmitting(true);
    try {
      if (isRegister) {
        await register(fullName, username, password);
      } else {
        await login(username, password);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const toggleMode = () => {
    setIsRegister((prev) => !prev);
    setAuthError('');
  };

  return (
    <KeyboardAvoidingView
      style={[styles.flex, { backgroundColor: c.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <View style={[styles.logoWrap, { backgroundColor: c.primary }]}>
          <Ionicons name="checkmark-done" size={28} color={c.accent} />
        </View>

        <Text style={[styles.heading, { color: c.textPrimary }]}>
          {isRegister ? 'Create account' : 'Welcome back'}
        </Text>
        <Text style={[styles.hint, { color: c.textSecondary }]}>
          Local login only — your account is saved on this device.
        </Text>

        <SpatialCard style={styles.formCard}>
          {isRegister && (
            <CustomInput
              label="Full name"
              placeholder="Juan Dela Cruz"
              value={fullName}
              onChangeText={setFullName}
            />
          )}
          <CustomInput
            label="Username"
            placeholder="Enter your username"
            autoCapitalize="none"
            value={username}
            onChangeText={setUsername}
          />
          <CustomInput
            label="Password"
            placeholder="Enter your password"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />

          {!!authError && <Text style={[styles.error, { color: c.danger }]}>{authError}</Text>}

          <CustomButton
            title={isRegister ? 'Register' : 'Log in'}
            onPress={onSubmit}
            loading={submitting}
            style={styles.submitBtn}
          />
        </SpatialCard>

        <Text style={[styles.switchText, { color: c.accent }]} onPress={toggleMode}>
          {isRegister ? 'Already have an account? Log in' : 'New here? Create an account'}
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { padding: 24, paddingTop: 72, paddingBottom: 40 },
  logoWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  heading: { fontSize: 26, fontWeight: '800', marginBottom: 6 },
  hint: { fontSize: 14, marginBottom: 24, lineHeight: 20 },
  formCard: { marginBottom: 20 },
  error: { marginBottom: 12, fontSize: 13, fontWeight: '600' },
  submitBtn: { marginTop: 4 },
  switchText: { textAlign: 'center', fontWeight: '700', fontSize: 14 },
});