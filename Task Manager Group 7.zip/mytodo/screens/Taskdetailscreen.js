import React from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useTasks } from '../context/TaskContext';
import { useTheme } from '../context/ThemeContext';
import SpatialCard from '../components/SpatialCard';
import PriorityBadge from '../components/PriorityBadge';
import CustomButton from '../components/CustomButton';

export default function TaskDetailScreen({ route, navigation }) {
  const { taskId } = route.params;
  const { tasks, toggleTask, deleteTask } = useTasks();
  const { theme } = useTheme();
  const c = theme.colors;

  const task = tasks.find((t) => t.id === taskId);

  if (!task) {
    return (
      <View style={[styles.container, { backgroundColor: c.background, justifyContent: 'center' }]}>
        <Text style={{ textAlign: 'center', color: c.textSecondary }}>This task no longer exists.</Text>
      </View>
    );
  }

  const confirmDelete = () => {
    Alert.alert('Delete task', `Remove "${task.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteTask(task.id);
          navigation.goBack();
        },
      },
    ]);
  };

  return (
    <ScrollView style={{ backgroundColor: c.background }} contentContainerStyle={styles.container}>
      <View
        style={[styles.statusPill, { backgroundColor: task.completed ? c.successSoft : c.surfaceMuted }]}
      >
        <Text style={[styles.statusText, { color: task.completed ? c.success : c.textSecondary }]}>
          {task.completed ? 'Completed' : 'Open'}
        </Text>
      </View>

      <Text style={[styles.title, { color: c.textPrimary }]}>{task.title}</Text>

      {!!task.description && (
        <Text style={[styles.description, { color: c.textSecondary }]}>{task.description}</Text>
      )}

      <SpatialCard style={styles.metaCard}>
        <View style={styles.metaRow}>
          <Text style={[styles.metaLabel, { color: c.textMuted }]}>Priority</Text>
          <PriorityBadge priority={task.priority} />
        </View>
        <View style={[styles.divider, { backgroundColor: c.border }]} />
        <View style={styles.metaRow}>
          <Text style={[styles.metaLabel, { color: c.textMuted }]}>Category</Text>
          <View style={[styles.categoryPill, { backgroundColor: c.primarySoft }]}>
            <Text style={{ color: c.primary, fontWeight: '700', fontSize: 12 }}>{task.category}</Text>
          </View>
        </View>
        {!!task.dueDate && (
          <>
            <View style={[styles.divider, { backgroundColor: c.border }]} />
            <View style={styles.metaRow}>
              <Text style={[styles.metaLabel, { color: c.textMuted }]}>Due date</Text>
              <Text style={{ color: c.textPrimary, fontWeight: '700', fontSize: 13 }}>{task.dueDate}</Text>
            </View>
          </>
        )}
      </SpatialCard>

      {!!task.createdAt && (
        <Text style={[styles.created, { color: c.textMuted }]}>
          Created {new Date(task.createdAt).toLocaleDateString()} at{' '}
          {new Date(task.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      )}

      <CustomButton
        title={task.completed ? 'Mark as open' : 'Mark as done'}
        onPress={() => toggleTask(task.id)}
        variant="primary"
        style={styles.btn}
      />
      <CustomButton
        title="Edit task"
        onPress={() => navigation.navigate('AddTask', { taskId: task.id })}
        variant="secondary"
        style={styles.btn}
      />
      <CustomButton title="Delete task" onPress={confirmDelete} variant="danger" style={styles.btn} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, paddingBottom: 40 },
  statusPill: {
    alignSelf: 'flex-start',
    borderRadius: 999,
    paddingVertical: 5,
    paddingHorizontal: 12,
    marginBottom: 14,
  },
  statusText: { fontSize: 12, fontWeight: '700' },
  title: { fontSize: 24, fontWeight: '800', marginBottom: 8 },
  description: { fontSize: 15, lineHeight: 22, marginBottom: 18 },
  metaCard: { marginBottom: 16 },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 4 },
  metaLabel: { fontSize: 12, fontWeight: '700' },
  divider: { height: 1, marginVertical: 8 },
  categoryPill: { borderRadius: 999, paddingVertical: 4, paddingHorizontal: 10 },
  created: { fontSize: 12, fontWeight: '600', marginBottom: 24 },
  btn: { marginBottom: 12 },
});