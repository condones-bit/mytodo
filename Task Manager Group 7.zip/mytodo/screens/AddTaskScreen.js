import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Switch } from 'react-native';
import { useTasks } from '../context/TaskContext';
import { useTheme } from '../context/ThemeContext';
import { PRIORITIES, CATEGORIES } from '../constants/storage';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import PriorityBadge from '../components/PriorityBadge';

export default function AddTaskScreen({ navigation, route }) {
  const { tasks, addTask, editTask } = useTasks();
  const { theme } = useTheme();
  const c = theme.colors;

  const taskId = route?.params?.taskId;
  const isEditing = !!taskId;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [category, setCategory] = useState('Other');
  const [completed, setCompleted] = useState(false);
  const [saving, setSaving] = useState(false);

  // In edit mode, load the existing task's values once tasks are available.
  useEffect(() => {
    if (isEditing) {
      const existing = tasks.find((t) => t.id === taskId);
      if (existing) {
        setTitle(existing.title);
        setDescription(existing.description || '');
        setDueDate(existing.dueDate || '');
        setPriority(existing.priority || 'Medium');
        setCategory(existing.category || 'Other');
        setCompleted(!!existing.completed);
      }
    }
  }, [isEditing, taskId, tasks]);

  useEffect(() => {
    navigation.setOptions({ title: isEditing ? 'Edit Task' : 'Add Task' });
  }, [isEditing, navigation]);

  const onSave = async () => {
    if (!title.trim()) {
      Alert.alert('Missing title', 'Please enter a task title.');
      return;
    }
    setSaving(true);
    const fields = { title, description, dueDate, priority, category, completed };
    try {
      if (isEditing) {
        await editTask(taskId, fields);
      } else {
        await addTask(fields);
      }
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={{ backgroundColor: c.background }} contentContainerStyle={styles.container}>
      <CustomInput
        label="Title"
        placeholder="e.g. Finish mobile project"
        value={title}
        onChangeText={setTitle}
      />
      <CustomInput
        label="Description"
        placeholder="Optional details"
        value={description}
        onChangeText={setDescription}
        multiline
      />
      <CustomInput
        label="Due date"
        placeholder="YYYY-MM-DD (optional)"
        value={dueDate}
        onChangeText={setDueDate}
        keyboardType="numbers-and-punctuation"
      />

      <Text style={[styles.sectionLabel, { color: c.textSecondary }]}>Priority</Text>
      <View style={styles.pillRow}>
        {PRIORITIES.map((p) => (
          <TouchableOpacity key={p} onPress={() => setPriority(p)} style={styles.pillWrap}>
            <View style={priority === p ? [styles.pillActiveRing, { borderColor: c.accent }] : null}>
              <PriorityBadge priority={p} />
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[styles.sectionLabel, { color: c.textSecondary }]}>Category</Text>
      <View style={styles.pillRow}>
        {CATEGORIES.map((cat) => {
          const active = category === cat;
          return (
            <TouchableOpacity
              key={cat}
              onPress={() => setCategory(cat)}
              style={[
                styles.categoryPill,
                {
                  backgroundColor: active ? c.primary : c.surfaceElevated,
                  borderColor: active ? c.primary : c.border,
                },
              ]}
            >
              <Text
                style={{ color: active ? c.textInverse : c.textSecondary, fontWeight: '700', fontSize: 13 }}
              >
                {cat}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {isEditing && (
        <View style={[styles.switchRow, { borderColor: c.border }]}>
          <Text style={[styles.switchLabel, { color: c.textPrimary }]}>Mark as completed</Text>
          <Switch
            value={completed}
            onValueChange={setCompleted}
            trackColor={{ false: c.border, true: c.accentSoft }}
            thumbColor={completed ? c.accent : c.surface}
          />
        </View>
      )}

      <CustomButton
        title={isEditing ? 'Save changes' : 'Save task'}
        onPress={onSave}
        loading={saving}
        style={styles.saveBtn}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 40 },
  sectionLabel: { fontSize: 12, fontWeight: '700', marginBottom: 8, marginTop: 4, letterSpacing: 0.3 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 18 },
  pillWrap: { marginRight: 8, marginBottom: 8 },
  pillActiveRing: { borderRadius: 999, borderWidth: 2 },
  categoryPill: {
    borderRadius: 999,
    borderWidth: 1.5,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 8,
    marginBottom: 8,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    borderTopWidth: 1,
    marginBottom: 18,
  },
  switchLabel: { fontSize: 15, fontWeight: '600' },
  saveBtn: { marginTop: 4 },
});