import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import CustomButton from '../components/CustomButton';

const STEPS = [
  { icon: 'bulb-outline', label: 'Plan' },
  { icon: 'layers-outline', label: 'Organize' },
  { icon: 'checkmark-circle-outline', label: 'Complete' },
];

export default function OnboardingScreen() {
  const { completeOnboarding } = useAuth();
  const { theme } = useTheme();
  const c = theme.colors;

  const fade = useRef(new Animated.Value(0)).current;
  const rise = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(rise, { toValue: 0, duration: 500, useNativeDriver: true }),
    ]).start();
  }, [fade, rise]);

  return (
    <View style={styles.container}>
      <Animated.View style={{ opacity: fade, transform: [{ translateY: rise }] }}>
        <Text style={[styles.badge, { color: c.accent }]}>MYTODO</Text>
        <Text style={styles.title}>Plan, organize, and complete your day</Text>
        <Text style={styles.subtitle}>
          A calm, spatial space to hold your tasks — everything you add stays saved right on this
          device.
        </Text>

        <View style={styles.stack}>
          {STEPS.map((step, i) => (
            <View
              key={step.label}
              style={[
                styles.floatCard,
                { marginTop: i === 0 ? 0 : -18, marginLeft: i * 18, opacity: 0.75 + i * 0.12 },
              ]}
            >
              <View style={[styles.floatIconWrap, { backgroundColor: c.accentSoft }]}>
                <Ionicons name={step.icon} size={20} color={c.accent} />
              </View>
              <Text style={styles.floatLabel}>{step.label}</Text>
            </View>
          ))}
        </View>

        <CustomButton title="Get Started" onPress={completeOnboarding} variant="primary" />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1626', padding: 28, justifyContent: 'center' },
  badge: { fontWeight: '800', letterSpacing: 3, marginBottom: 14, fontSize: 13 },
  title: { color: '#FFFFFF', fontSize: 30, fontWeight: '800', lineHeight: 38, marginBottom: 12 },
  subtitle: { color: '#C9D6E5', fontSize: 15, lineHeight: 22, marginBottom: 40 },
  stack: { marginBottom: 48 },
  floatCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 16,
    width: '80%',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  floatIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  floatLabel: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
});