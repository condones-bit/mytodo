import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTasks } from '../context/TaskContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import TaskCard from '../components/TaskCard';
import StatCard from '../components/StatCard';
import SpatialCard from '../components/SpatialCard';
import EmptyState from '../components/EmptyState';
import FloatingActionButton from '../components/FloatingActionButton';

const FILTERS = ['All', 'Today', 'Pending', 'Completed', 'High Priority'];

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export default function TodoListScreen({ navigation }) {
  const { user } = useAuth();
  const { tasks, toggleTask, deleteTask } = useTasks();
  const { theme, mode, toggleTheme } = useTheme();
  const c = theme.colors;

  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');

  const total = tasks.length;
  const completed = tasks.filter((t) => t.completed).length;
  const pending = total - completed;
  const highPriority = tasks.filter((t) => t.priority === 'High').length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;

  const filteredTasks = useMemo(() => {
    let list = tasks;
    if (filter === 'Today') list = list.filter((t) => t.dueDate === todayISO());
    else if (filter === 'Pending') list = list.filter((t) => !t.completed);
    else if (filter === 'Completed') list = list.filter((t) => t.completed);
    else if (filter === 'High Priority') list = list.filter((t) => t.priority === 'High');

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (t) => t.title.toLowerCase().includes(q) || (t.description || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [tasks, filter, search]);

  const confirmDelete = (id, title) => {
    Alert.alert('Delete task', `Remove "${title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => deleteTask(id) },
    ]);
  };

  const initial = (user?.fullName || user?.username || 'U').charAt(0).toUpperCase();

  return (
    <View style={[styles.container, { backgroundColor: c.background }]}>
      <FlatList
        data={filteredTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskCard
            task={item}
            onPress={() => navigation.navigate('TaskDetail', { taskId: item.id })}
            onToggle={() => toggleTask(item.id)}
            onDelete={() => confirmDelete(item.id, item.title)}
          />
        )}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View>
            <View style={styles.header}>
              <View>
                <Text style={[styles.greeting, { color: c.textSecondary }]}>{getGreeting()},</Text>
                <Text style={[styles.name, { color: c.textPrimary }]}>
                  {user?.fullName || user?.username}
                </Text>
              </View>
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={toggleTheme}
                  style={[styles.iconBtn, { backgroundColor: c.surfaceElevated, borderColor: c.border }]}
                >
                  <Ionicons
                    name={mode === 'dark' ? 'sunny-outline' : 'moon-outline'}
                    size={18}
                    color={c.textSecondary}
                  />
                </TouchableOpacity>
                <View style={[styles.avatar, { backgroundColor: c.primary }]}>
                  <Text style={[styles.avatarText, { color: c.accent }]}>{initial}</Text>
                </View>
              </View>
            </View>

            <SpatialCard style={styles.progressCard}>
              <View style={styles.progressTop}>
                <Text style={[styles.progressTitle, { color: c.textPrimary }]}>Today's Progress</Text>
                <Text style={[styles.progressPct, { color: c.accent }]}>{progress}%</Text>
              </View>
              <View style={[styles.progressTrack, { backgroundColor: c.surfaceMuted }]}>
                <View style={[styles.progressFill, { width: `${progress}%`, backgroundColor: c.accent }]} />
              </View>
              <Text style={[styles.progressSub, { color: c.textSecondary }]}>
                {completed} of {total} task{total === 1 ? '' : 's'} done
              </Text>
            </SpatialCard>

            <View style={styles.statsGrid}>
              <View style={styles.statsRow}>
                <StatCard label="Total" value={total} tone="primary" />
                <View style={{ width: 10 }} />
                <StatCard label="Completed" value={completed} tone="success" />
              </View>
              <View style={{ height: 10 }} />
              <View style={styles.statsRow}>
                <StatCard label="Pending" value={pending} tone="warning" />
                <View style={{ width: 10 }} />
                <StatCard label="High Priority" value={highPriority} tone="danger" />
              </View>
            </View>

            <View style={[styles.searchRow, { backgroundColor: c.surfaceElevated, borderColor: c.border }]}>
              <Ionicons name="search-outline" size={18} color={c.textMuted} />
              <TextInput
                style={[styles.searchInput, { color: c.textPrimary }]}
                placeholder="Search tasks..."
                placeholderTextColor={c.textMuted}
                value={search}
                onChangeText={setSearch}
              />
            </View>

            <FlatList
              data={FILTERS}
              keyExtractor={(f) => f}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filterRow}
              renderItem={({ item }) => {
                const active = filter === item;
                return (
                  <TouchableOpacity
                    onPress={() => setFilter(item)}
                    style={[
                      styles.filterPill,
                      {
                        backgroundColor: active ? c.accent : c.surfaceElevated,
                        borderColor: active ? c.accent : c.border,
                      },
                    ]}
                  >
                    <Text style={[styles.filterText, { color: active ? c.white : c.textSecondary }]}>
                      {item}
                    </Text>
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        }
        ListEmptyComponent={
          <EmptyState
            icon="file-tray-outline"
            title={tasks.length === 0 ? 'No tasks yet' : 'No matching tasks'}
            subtitle={
              tasks.length === 0
                ? 'Create your first task and start organizing your day.'
                : 'Try a different search or filter.'
            }
          />
        }
      />

      <FloatingActionButton onPress={() => navigation.navigate('AddTask')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, paddingBottom: 100 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 18,
  },
  greeting: { fontSize: 14, fontWeight: '600' },
  name: { fontSize: 22, fontWeight: '800' },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    marginRight: 10,
  },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 18, fontWeight: '800' },

  progressCard: { marginBottom: 14 },
  progressTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  progressTitle: { fontSize: 15, fontWeight: '700' },
  progressPct: { fontSize: 20, fontWeight: '800' },
  progressTrack: { height: 10, borderRadius: 5, overflow: 'hidden', marginBottom: 8 },
  progressFill: { height: '100%', borderRadius: 5 },
  progressSub: { fontSize: 13, fontWeight: '600' },

  statsGrid: { marginBottom: 16 },
  statsRow: { flexDirection: 'row' },

  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 12,
  },
  searchInput: { flex: 1, marginLeft: 8, fontSize: 14 },

  filterRow: { paddingBottom: 4, marginBottom: 6 },
  filterPill: {
    borderRadius: 999,
    borderWidth: 1,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 8,
  },
  filterText: { fontSize: 13, fontWeight: '700' },
});