import React from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../context/TaskContext';
import { useTheme } from '../context/ThemeContext';
import SpatialCard from '../components/SpatialCard';
import StatCard from '../components/StatCard';
import CustomButton from '../components/CustomButton';

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const { tasks } = useTasks();
  const { mode, toggleTheme, theme } = useTheme();
  const c = theme.colors;

  const total = tasks.length;
  const completed = tasks.filter((t) => t.completed).length;
  const pending = total - completed;
  const rate = total > 0 ? Math.round((completed / total) * 100) : 0;

  const onLogout = () => {
    Alert.alert('Log out', 'You can log in again with the same account on this device.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log out', style: 'destructive', onPress: logout },
    ]);
  };

  const initial = (user?.fullName || user?.username || 'U').charAt(0).toUpperCase();

  return (
    <ScrollView style={{ backgroundColor: c.background }} contentContainerStyle={styles.container}>
      <View style={styles.headerBlock}>
        <View style={[styles.avatar, { backgroundColor: c.primary }]}>
          <Text style={[styles.avatarText, { color: c.accent }]}>{initial}</Text>
        </View>
        <Text style={[styles.name, { color: c.textPrimary }]}>{user?.fullName}</Text>
        <Text style={[styles.username, { color: c.textSecondary }]}>@{user?.username}</Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard label="Completed" value={completed} tone="success" />
        <View style={{ width: 10 }} />
        <StatCard label="Pending" value={pending} tone="warning" />
        <View style={{ width: 10 }} />
        <StatCard label="Rate" value={`${rate}%`} tone="accent" />
      </View>

      <SpatialCard style={styles.sectionCard}>
        <Text style={[styles.sectionTitle, { color: c.textPrimary }]}>Account</Text>
        <View style={styles.row}>
          <Text style={[styles.rowLabel, { color: c.textSecondary }]}>Full name</Text>
          <Text style={[styles.rowValue, { color: c.textPrimary }]}>{user?.fullName}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: c.border }]} />
        <View style={styles.row}>
          <Text style={[styles.rowLabel, { color: c.textSecondary }]}>Username</Text>
          <Text style={[styles.rowValue, { color: c.textPrimary }]}>{user?.username}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: c.border }]} />
        <View style={styles.row}>
          <Text style={[styles.rowLabel, { color: c.textSecondary }]}>Total tasks</Text>
          <Text style={[styles.rowValue, { color: c.textPrimary }]}>{total}</Text>
        </View>
      </SpatialCard>

      <SpatialCard style={styles.sectionCard}>
        <Text style={[styles.sectionTitle, { color: c.textPrimary }]}>Settings</Text>
        <View style={styles.row}>
          <View style={styles.settingLabelWrap}>
            <Ionicons
              name={mode === 'dark' ? 'moon' : 'sunny'}
              size={18}
              color={c.accent}
              style={{ marginRight: 8 }}
            />
            <Text style={[styles.rowLabel, { color: c.textPrimary }]}>Dark mode</Text>
          </View>
          <Switch
            value={mode === 'dark'}
            onValueChange={toggleTheme}
            trackColor={{ false: c.border, true: c.accentSoft }}
            thumbColor={mode === 'dark' ? c.accent : c.surface}
          />
        </View>
      </SpatialCard>

      <CustomButton title="Log out" onPress={onLogout} variant="danger" style={styles.logoutBtn} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 40 },
  headerBlock: { alignItems: 'center', marginBottom: 20 },
  avatar: {
    width: 84,
    height: 84,
    borderRadius: 42,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarText: { fontSize: 32, fontWeight: '800' },
  name: { fontSize: 22, fontWeight: '800' },
  username: { fontSize: 14, marginTop: 2 },

  statsRow: { flexDirection: 'row', marginBottom: 16 },

  sectionCard: { marginBottom: 16 },
  sectionTitle: { fontSize: 14, fontWeight: '800', marginBottom: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8 },
  rowLabel: { fontSize: 13, fontWeight: '600' },
  rowValue: { fontSize: 13, fontWeight: '700' },
  divider: { height: 1 },
  settingLabelWrap: { flexDirection: 'row', alignItems: 'center' },

  logoutBtn: { marginTop: 4 },
});