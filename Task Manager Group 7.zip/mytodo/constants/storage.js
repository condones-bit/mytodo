export const STORAGE_KEYS = {
  ONBOARDED: '@mytodo_onboarded',
  USERS: '@mytodo_users',
  SESSION: '@mytodo_session',
  TASKS: '@mytodo_tasks',
  THEME: '@mytodo_theme',
};

export const PRIORITIES = ['Low', 'Medium', 'High'];
export const CATEGORIES = ['School', 'Personal', 'Work', 'Other'];

/**
 * Task object stored in AsyncStorage (JSON array under `${STORAGE_KEYS.TASKS}:{username}`)
 * {
 *   id: string,
 *   title: string,
 *   description: string,
 *   dueDate: string,       // "YYYY-MM-DD" or "" if not set
 *   priority: 'Low' | 'Medium' | 'High',
 *   category: 'School' | 'Personal' | 'Work' | 'Other',
 *   completed: boolean,
 *   createdAt: string (ISO date)
 * }
 */
export function createTask({
  title,
  description = '',
  dueDate = '',
  priority = 'Medium',
  category = 'Other',
} = {}) {
  return {
    id: Date.now().toString() + Math.random().toString(16).slice(2),
    title: (title || '').trim(),
    description: (description || '').trim(),
    dueDate: dueDate || '',
    priority: PRIORITIES.includes(priority) ? priority : 'Medium',
    category: CATEGORIES.includes(category) ? category : 'Other',
    completed: false,
    createdAt: new Date().toISOString(),
  };
}