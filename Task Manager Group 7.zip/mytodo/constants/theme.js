// Design system for the app.
//
// `spacing`, `radius`, `type`, and `shadow` are shared between light and dark mode.
// `lightColors` / `darkColors` are the two color palettes; `lightTheme` / `darkTheme`
// bundle a palette together with the shared scales into one object that components
// read through `useTheme()` (see context/ThemeContext.js).
//
// `colors` is kept as a plain export of the light palette for any older code that
// still does `import { colors } from '../constants/theme'` directly.

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const radius = {
  sm: 10,
  md: 14,
  lg: 20,
  xl: 28,
  pill: 999,
};

// Font only — no color here. Colors are theme-dependent, so components apply
// color separately from `theme.colors`, e.g.:
//   <Text style={[type.title, { color: theme.colors.textPrimary }]}>
export const type = {
  display: { fontSize: 26, fontWeight: '800' },
  title: { fontSize: 18, fontWeight: '700' },
  body: { fontSize: 15, fontWeight: '500' },
  secondary: { fontSize: 14, fontWeight: '500' },
  caption: { fontSize: 12, fontWeight: '600' },
};

export const shadow = {
  card: {
    shadowColor: '#000000',
    shadowOpacity: 0.08,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  fab: {
    shadowColor: '#000000',
    shadowOpacity: 0.25,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
};

export const lightColors = {
  background: '#F6F8FB',
  surface: '#FFFFFF',
  surfaceMuted: '#EEF2F7',
  surfaceElevated: '#FFFFFF',
  glass: 'rgba(255,255,255,0.65)',
  border: '#E3E9F1',

  textPrimary: '#122744',
  textSecondary: '#64758B',
  textMuted: '#9AAAC0',
  textInverse: '#FFFFFF',

  primary: '#122744', // navy — brand/primary surfaces (headers, avatars, secondary buttons)
  primarySoft: '#E7ECF3',
  accent: '#22B8A6', // teal — main accent (buttons, active states, FAB)
  accentSoft: '#DFF6F2',
  secondary: '#E8604C', // coral — secondary accent
  secondarySoft: '#FBE4E0',

  success: '#22B8A6',
  successSoft: '#DFF6F2',
  warning: '#F0A93A',
  warningSoft: '#FCEED2',
  danger: '#E8604C',
  dangerSoft: '#FBE4E0',

  white: '#FFFFFF',
  black: '#0B1626',
};

export const darkColors = {
  background: '#0B1626',
  surface: '#142B45',
  surfaceMuted: '#1B3350',
  surfaceElevated: '#18314E',
  glass: 'rgba(20,43,69,0.65)',
  border: '#22415F',

  textPrimary: '#F2F6FB',
  textSecondary: '#A9BBD1',
  textMuted: '#7488A3',
  textInverse: '#0B1626',

  primary: '#7EE0D6',
  primarySoft: '#1E3A52',
  accent: '#2FD6C4',
  accentSoft: 'rgba(47,214,196,0.16)',
  secondary: '#FF8A72',
  secondarySoft: 'rgba(255,138,114,0.16)',

  success: '#2FD6C4',
  successSoft: 'rgba(47,214,196,0.16)',
  warning: '#FFB65C',
  warningSoft: 'rgba(255,182,92,0.16)',
  danger: '#FF6B5B',
  dangerSoft: 'rgba(255,107,91,0.16)',

  white: '#FFFFFF',
  black: '#000000',
};

export const lightTheme = { mode: 'light', colors: lightColors, spacing, radius, type, shadow };
export const darkTheme = { mode: 'dark', colors: darkColors, spacing, radius, type, shadow };

// Backward-compatible export for any file still importing `colors` directly.
export const colors = lightColors;